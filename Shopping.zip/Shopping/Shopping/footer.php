<section class="footer">

    <div class="box-container">

        <div class="box">
            <p> <i class="fas fa-envelope"></i> binjachchaimaa@gmail.com </p>

        </div>
        <div class="box">
            <a href="https://www.linkedin.com/in/chaimae-binjach-89a9b3253/"> <i class="fab fa-linkedin"></i> linkedin </a>
        </div>



</section>